import pygame
from pygame.locals import *
pygame.init()


screen = pygame.display.set_mode((800, 600))

menu_bg = pygame.image.load("image/menu_bg.png").convert_alpha()
menu_bg = pygame.transform.scale(menu_bg, (800, 600))

unravel_button = pygame.image.load("image/unravel_button.png").convert_alpha()
unravel_button = pygame.transform.scale(unravel_button, (200, 100))

rick_button = pygame.image.load("image/rick_button.png").convert_alpha()
rick_button = pygame.transform.scale(rick_button, (200, 100))

clicked = False

class Button:


   
    def __init__(self, x, y, image):
        self.x = x
        self.y = y
        self.image = image

    def draw_button(self):

        global clicked
        action = False

        #get mouse position
        pos = pygame.mouse.get_pos()

        #create pygame Rect object for the button
        button_rect =  self.image.get_rect(center = (self.x, self.y))

        #check mouseover and clicked conditions
        if button_rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and clicked == False:
                clicked = True
                screen.blit(self.image, button_rect)
            elif pygame.mouse.get_pressed()[0] == 0 and clicked == True:
                clicked = False
                action = True
            else:
                screen.blit(self.image, button_rect)
        else:
            screen.blit(self.image, button_rect)

        return action

a = Button(390, 100, unravel_button)

b = Button(390, 300, rick_button)

running = True


while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.blit(menu_bg, (0, 0))
    if a.draw_button():

        print("1")

    if b.draw_button():
        print("2")

    # if rick_button.draw_button():
        # unravel_button.set_false()
        # print("yo")

    pygame.display.update()
