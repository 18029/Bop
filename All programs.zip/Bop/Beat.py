import pygame
import random
import math
import time
from pygame import mixer

note_time = []
space_key = "idle"


song = open("timing/harumachiclover_timing.txt", "w")

pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((800, 600))
            

mixer.music.load("music/harumachiclover.mp3")
mixer.music.set_volume(0.09)
mixer.music.play()

running = True
while running:
    clock.tick(120)
    
            
    seconds = pygame.time.get_ticks()/1000


    # RGB = Red, Green, Blue
    screen.fill((255, 255, 255))
    # Background Image
   
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            for i in range(len(note_time)):    
                song.write(str(note_time[i]) + ", ")
            song.close()
            running = False
    
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                space_key = "pressed"  
                note_time.append(seconds)     
                
   
    
    
    pygame.display.update() 




     
     
   
   
    
            
              

     
    
