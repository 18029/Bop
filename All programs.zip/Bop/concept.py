#highscore = open("highscorefile.txt", "r")
#highscore_list = highscore.read()


#highscore_list = (highscore_list.split(","))

#for i in range(len(highscore_list)):
    #highscore_list[i] = int(highscore_list[i])
    
#highscore_list[2] = 0

highscore_f = ', '.join(str(i) for i in highscore_list)


highscore_w = open("highscorefile.txt", "w")
highscore_w.write(f)



#highscore_w.seek(6)
#highscore_w.write("3")    
print("True True")
