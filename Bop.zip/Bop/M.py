import pygame


class Button():
    def __init__(self, x, y, image):
    
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.clicked = False

    def draw(self, surface):
        action = False
        #get mouse position
        pos = pygame.mouse.get_pos()

        #check mouseover and clicked conditions
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                action = True
        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False

        #draw button on screen
        surface.blit(self.image, (self.rect.x, self.rect.y))

        return action

screen = pygame.display.set_mode((800, 600))

menu_bg = pygame.image.load("image/menu_bg.png").convert_alpha()
menu_bg = pygame.transform.scale(menu_bg, (800, 600))

unravel_button = pygame.image.load("image/unravel_button.png").convert_alpha()
unravel_button = pygame.transform.scale(unravel_button, (400, 300))

rick_button = pygame.image.load("image/rick_button.png").convert_alpha()
rick_button = pygame.transform.scale(rick_button, (400, 300))

#create button instances
a = Button(390, 100, unravel_button)
b = Button(390, 150, rick_button)

#game loop
run = True
while run:

    screen.fill((202, 228, 241))
    
    #event handler
    for event in pygame.event.get():
        #quit game
        if event.type == pygame.QUIT:
            run = False    

    if a.draw(screen):
        print('1')
    if b.draw(screen):
        print('2')



    pygame.display.update()

pygame.quit()


