import pygame
from pygame.locals import *

pygame.init()


screen = pygame.display.set_mode((800, 600))
menu_bg = pygame.image.load("image/menu_bg.png").convert_alpha()
menu_bg = pygame.transform.scale(menu_bg, (800, 600))


font = pygame.font.Font('font/Pixeltype.ttf', 50)


#define global variable
clicked = False


class Word_Button():

            #colours for button and text
            button_col = (255,192,203)
            hover_col = (75, 225, 255)
            click_col = (50, 150, 255)
            text_col = (255, 255, 255)
            width = 200
            height = 70

            def __init__(self, x, y, text):
                        self.x = x
                        self.y = y
                        self.text = text
                        self.clicked = False

            def draw_wbutton(self):

                        
                        action = False

                        #get mouse position
                        pos = pygame.mouse.get_pos()

                        #create pygame Rect object for the button
                        button_rect = Rect(self.x, self.y, self.width, self.height)
                        

                        #check mouseover and clicked conditions
                        if button_rect.collidepoint(pos):
                                    if pygame.mouse.get_pressed()[0] == 1:
                                                self.clicked = True
                                                pygame.draw.rect(screen, self.click_col, button_rect)
                                    elif pygame.mouse.get_pressed()[0] == 0 and self.clicked == True:
                                                self.clicked = False
                                                action = True
                                    else:
                                                pygame.draw.rect(screen, self.hover_col, button_rect)
                        else:
                                    pygame.draw.rect(screen, self.button_col, button_rect)

                     
            
                        #add text to button
                        text_img = font.render(self.text, True, self.text_col)
                        text_len = text_img.get_width()
                        screen.blit(text_img, (self.x + int(self.width / 2) - int(text_len / 2), self.y + 25))
                       
                        return action






a = Word_Button(390, 50, "Unravel")

b = Word_Button(390, 120, "Rick")

running = True


while running:

            for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                                    running = False

            screen.blit(menu_bg, (0, 0))
            
            if a.draw_wbutton():
                        print("1")            
         
            
            if b.draw_wbutton() == True:
                        print("hi")
                 
          
      
                        
                        


            pygame.display.update()
