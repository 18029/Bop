import os
os.startfile("C:\Users\danie\Game 1.5\Game 1.5\new_game.exe")

   